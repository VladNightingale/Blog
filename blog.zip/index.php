<?php 


	include("config.php");
	include CONTROLLER;

 ?>